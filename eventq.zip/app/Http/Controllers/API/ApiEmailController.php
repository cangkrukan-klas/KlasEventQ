<?php
/**
 * Created by PhpStorm.
 * User: nathanael79
 * Date: 13/08/18
 * Time: 21:42
 */

namespace App\Http\Controllers\API;


use App\Http\Controllers\Controller;

class ApiEmailController extends Controller
{
    public function confirm_regis()
    {
        //if();
    }

}